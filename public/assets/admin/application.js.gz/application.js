(function() {

  $(document).on("page:fetch", function() {
    return $('.content').hide();
  });

}).call(this);
